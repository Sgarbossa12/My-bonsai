# My Bonsai — free starter

Mobile-friendly starter web app. Features: tree records, photos, yamadori/type and seed origin fields, editable soil mixes with percentage total validation, JSON backup and restore.

## Use
Open `index.html` in a browser to test. For installable home-screen use, host on an HTTPS static host (for example GitHub Pages). Then open the site in Chrome and use the menu → Add to Home screen.

## Data warning
Records are stored in browser localStorage on that device and browser. Clearing site data may erase them. Export backups regularly. This starter has no cloud sync/database yet. Backup JSON includes embedded photos.
